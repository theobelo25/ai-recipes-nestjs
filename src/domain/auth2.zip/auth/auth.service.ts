import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { HashingService } from './hashing/hashing.service';
import { UsersService } from 'src/domain/users/users.service';
import { JwtService } from '@nestjs/jwt';
import { JwtPayload } from './interfaces/jwt-payload.interface';
import { RequestUser } from './interfaces/request-user.interface';
import { ChangePasswordDto, SignupDto } from './types/auth.schema';
import { PrismaService } from 'src/prisma/prisma.service';
import { SAFE_USER_SELECT } from '../users/types/users.constants';

@Injectable()
export class AuthService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly usersService: UsersService,
    private readonly hashingService: HashingService,
    private readonly jwtService: JwtService,
  ) {}

  async signup(signupDto: SignupDto) {
    const { email, password } = signupDto;

    const existingUser = await this.usersService.findPrivateUserByEmail(email);
    if (existingUser)
      throw new ConflictException(
        'A user with this email address already exists.',
      );

    const hashedPassword = await this.hashingService.hash(password);

    return await this.prismaService.user.create({
      data: { ...signupDto, password: hashedPassword },
      select: SAFE_USER_SELECT,
    });
  }

  async validateLocal(email: string, password: string) {
    const user = await this.usersService.findPrivateUserByEmail(email);
    if (!user) throw new UnauthorizedException('Invalid credentials.');

    const isMatch = await this.hashingService.compare(password, user.password);
    if (!isMatch) throw new UnauthorizedException('Invalid credentials.');

    const requestUser: RequestUser = { id: user.id };
    return requestUser;
  }

  async validateJwt({ sub }: JwtPayload) {
    const user = await this.usersService.findPrivateUserById(sub);
    if (!user) throw new UnauthorizedException('Invalid token.');

    const requestUser: RequestUser = { id: user.id };
    return requestUser;
  }

  async signAccessToken(userId: string): Promise<string> {
    const payload: JwtPayload = { sub: userId };
    const accessToken = await this.jwtService.signAsync(payload);
    if (!accessToken) throw new UnauthorizedException('Problem signing token.');

    return accessToken;
  }

  async changePassword(id: string, changePassword: ChangePasswordDto) {
    const { oldPassword, newPassword } = changePassword;

    const user = await this.usersService.findPrivateUserById(id);

    const passwordMatches = await this.hashingService.compare(
      oldPassword,
      user.password,
    );
    if (!passwordMatches)
      throw new UnauthorizedException('User not authorized.');

    const newHashedPassword = await this.hashingService.hash(newPassword);

    let updatedUser;
    await this.prismaService.$transaction(async (tx) => {
      updatedUser = await tx.user.update({
        where: { id },
        data: { password: newHashedPassword },
        select: SAFE_USER_SELECT,
      });

      await tx.refreshToken.updateMany({
        where: { userId: id, revokedAt: null },
        data: { revokedAt: new Date() },
      });
    });

    return updatedUser;
  }
}
