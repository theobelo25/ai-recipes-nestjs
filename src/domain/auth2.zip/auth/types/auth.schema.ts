import { Type, Static } from '@sinclair/typebox';

export const signinSchema = Type.Object(
  {
    email: Type.String({ format: 'email' }),
    password: Type.String({ minLength: 8 }),
  },
  {
    required: ['email', 'password'],
    additionalProperties: false,
    errorMessage: {
      properties: {
        email: 'Invalid email format.',
        password: 'Password must be at least 8 characters long.',
      },
      required: {
        email: 'Email is required.',
        password: 'Password is required.',
      },
      additionalProperties: 'No additional properties are allowed.',
    },
  },
);

export type SigninDto = Static<typeof signinSchema>;

export const signupSchema = Type.Object(
  {
    username: Type.String({
      transform: ['trim'],
      minLength: 3,
      maxLength: 50,
      pattern: '^[a-zA-Z\\s]*$',
    }),
    email: Type.String({
      transform: ['trim'],
      format: 'email',
    }),
    password: Type.String({
      transform: ['trim'],
      minLength: 8,
      maxLength: 32,
      pattern: '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*]).{8,32}$',
    }),
    confirmPassword: Type.String({
      transform: ['trim'],
      const: { $data: '1/password' },
    }),
  },
  {
    required: ['username', 'email', 'password', 'confirmPassword'],
    additionalProperties: false,
    errorMessage: {
      properties: {
        username:
          'Username must be between 3 and 50 characters long and only contain letters, spaces, or hyphens.',
        email: 'Invalid email format.',
        password:
          'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character from the following !@#$%^&*.',
        confirmPassword: 'confirmPassword must match password exactly',
      },
      required: {
        username: 'Username is required.',
        email: 'Email is required.',
        password: 'Password is required.',
        confirmPassword: 'confirmPassword is required.',
      },
      additionalProperties: 'No additional properties are allowed.',
    },
  },
);

export type SignupDto = Static<typeof signupSchema>;

export const ChangePasswordSchema = Type.Object(
  {
    oldPassword: Type.String({ minLength: 8 }),
    newPassword: Type.String({
      transform: ['trim'],
      minLength: 8,
      maxLength: 32,
      pattern: '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*]).{8,32}$',
    }),
    confirmNewPassword: Type.String({
      transform: ['trim'],
      const: { $data: '1/password' },
    }),
  },
  {
    required: ['oldPassword', 'newPassword', 'confirmNewPassword'],
    additionalProperties: false,
    errorMessage: {
      properties: {
        newPassword:
          'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character from the following !@#$%^&*.',
        confirmPassword: 'confirmPassword must match password exactly',
      },
      required: {
        username: 'Username is required.',
        oldPassword: 'Old password is required.',
        newPassword: 'New password is required.',
        confirmNewPassword: 'Password confirmation is required.',
      },
      additionalProperties: 'No additional properties are allowed.',
    },
  },
);

export type ChangePasswordDto = Static<typeof ChangePasswordSchema>;
