export interface RequestUser {
  readonly id: string;
}
