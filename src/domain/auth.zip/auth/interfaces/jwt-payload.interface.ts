export interface JwtPayload {
  readonly sub: string;
}
