import { RefreshRotateGuard } from './refresh-rotate.guard';

describe('RefreshRotateGuard', () => {
  it('should be defined', () => {
    expect(new RefreshRotateGuard()).toBeDefined();
  });
});
