import { OriginGuard } from './origin.guard';

describe('OriginGuard', () => {
  it('should be defined', () => {
    expect(new OriginGuard()).toBeDefined();
  });
});
