export const REFRESH_COOKIE = 'refreshToken' as const;
