import { Db } from 'src/common/db/db.type';
import {
  CreateIngredientDto,
  UpdateIngredientDto,
} from '../types/ingredient.schema';
import { IngredientDto } from '../types/ingredient.types';

export const INGREDIENTS_REPOSITORY = Symbol('INGREDIENTS_REPOSITORY');

export interface IIngredientsRepository {
  create(
    dto: CreateIngredientDto,
    slug: string,
    db?: Db,
  ): Promise<IngredientDto>;
  findAll(db?: Db): Promise<IngredientDto[]>;
  findOneBySlug(slug: string, db?: Db): Promise<IngredientDto>;
  updateBySlug(
    slug: string,
    data: UpdateIngredientDto,
    db?: Db,
  ): Promise<IngredientDto>;
  removeBySlug(slug: string, db?: Db): Promise<IngredientDto>;
  ensureByName(name: string, slug: string, db?: Db): Promise<IngredientDto>;
}
